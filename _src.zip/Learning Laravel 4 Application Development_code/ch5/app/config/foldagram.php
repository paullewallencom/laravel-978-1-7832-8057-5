<?php

return array('price' => 5);