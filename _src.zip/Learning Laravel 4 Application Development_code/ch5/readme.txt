From the root directory of project via commandline run,

1. $  composer install -d workbench/acme/cart

2. $  composer dump-autoload

3. $  composer update

4. change database settings in database.php to match your database

5. run migrations via 

   $ php artisan migrate 

---------------------
view routes.php file to check possible options to explore.

enjoy :)