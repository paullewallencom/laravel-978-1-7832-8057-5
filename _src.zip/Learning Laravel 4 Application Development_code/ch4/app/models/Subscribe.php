<?php

class Subscribe extends Eloquent{

	protected $table = 'subscribe';
	protected $fillable = array('email');

}