1. $ composer update

2. change database settings in database.php to match your database

3. run migrations via 

	$ php artisan migrate 

to get all tables for the chapter.

then you can hit following url's to check our app.

http://<yourserver>/
http://<yourserver>/about

you can check foldagram via create foldagram link