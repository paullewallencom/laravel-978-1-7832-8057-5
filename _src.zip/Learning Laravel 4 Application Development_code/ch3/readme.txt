
1) run 

$ composer update

to get all packages

2) change database.php file with correct db settings.

use users.sql file to create your database table via phpmyadmin

3) <yourservername>/users

enjoy :)