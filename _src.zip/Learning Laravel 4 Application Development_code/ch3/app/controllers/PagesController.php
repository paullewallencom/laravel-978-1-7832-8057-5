<?php
class PagesController extends BaseController {


  public function contact()
  {
	return View::make('hello');
  }

}