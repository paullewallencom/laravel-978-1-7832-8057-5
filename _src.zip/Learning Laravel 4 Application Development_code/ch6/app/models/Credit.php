<?php

class Credit extends Eloquent {

     protected $table = 'credit';



}