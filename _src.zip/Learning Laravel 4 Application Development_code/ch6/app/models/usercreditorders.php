<?php

class UserCreditOrders extends Eloquent {

     protected $table = 'usercreditorders';


}