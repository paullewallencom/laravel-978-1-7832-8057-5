<?php

return array(
	'api_key' => 'sk_test_noyUE53Icn1SnYC3pTfYpTec',

	'publishable_key' => 'pk_test_TWK6aAHhCWPMmya8XMCDhv4J'
);